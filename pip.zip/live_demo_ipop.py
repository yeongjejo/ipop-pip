import torch
import struct
from pygame.time import Clock
from net import PIP
import articulate as art
import os
from config import *
#import keyboard
from data_manager import DataManager
from protocol.udp_server import UDPServer
from protocol.udp_station_broadcast_receiver import UDPStationBroadcastReceiver
import time
import socket
import numpy as np
import matplotlib.pyplot as plt

class IMUSet:
    g = 9.8
    test_i = -1

    def __init__(self, test):

        self.n_imus = 6
        self.test = test


    def get_noitom(self):
        try:
            data, addr = self.cs.recvfrom(172)
            format = '>f'

            parsed_data = [struct.unpack(format, data[i:i + 4])[0] for i in range(2, len(data) - 2, 4)]

            np_data = np.array(parsed_data)

            q, a = [], []
            for i in range(0, 42, 7):
                q.append([np_data[i], np_data[i + 1], np_data[i + 2], np_data[i + 3]])
                a.append([np_data[i + 4], np_data[i + 5], np_data[i + 6]])
                #quat = torch.tensor([np_data[i], np_data[i + 1], np_data[i + 2], np_data[i + 3]])
                #acc = torch.tensor([np_data[i + 4], np_data[i + 5], np_data[i + 6]])
                #q.append(quat)
                #a.append(acc)

            R = art.math.quaternion_to_rotation_matrix(torch.tensor(q))  # rotation is not changed
            a = -torch.tensor(a) / 1000 * self.g  # acceleration is reversed
            a = R.bmm(a.unsqueeze(-1)).squeeze(-1) + torch.tensor([0., 0., self.g])  # calculate global free acceleration
            return R, a

        except socket.timeout:
            print('[warning] no imu data received for 3 seconds')

    def get_ipop(self):
        if self.test:
            test_a_list, test_q_list, _ = DataManager().process_dipimu()
            self.test_i += 1

            q = test_q_list[self.test_i]
            a = test_a_list[self.test_i]
            # a = -torch.tensor(a) / 1000 * 9.8                        # acceleration is reversed
            # a = q.bmm(a.unsqueeze(-1)).squeeze(-1) + torch.tensor([0., 0., 9.8])   # calculate global free acceleration

            
            return q, a


        a = DataManager().test_acc
        q = DataManager().test_q
        r = DataManager().test_r
	
        return r, a



    def clear(self):
        pass
def tpose_calibration_ipop():
    #c = input('Used cached RMI? [y]/n    (If you choose no, put imu 1 straight (x = Forward, y = Left, z = Up).')
    #if c == 'n' or c == 'N':
    #    imu_set.clear()
    #    RSI = art.math.quaternion_to_rotation_matrix(torch.tensor(imu_set.get_ipop()[0][0])).view(3, 3).t()
    #    RMI = torch.tensor([[0, 1, 0], [0, 0, 1], [1, 0, 0]], dtype=torch.double).mm(RSI)
    #    torch.save(RMI, os.path.join(paths.temp_dir, 'RMI.pt'))
    #else:
    #    RMI = torch.load(os.path.join(paths.temp_dir, 'RMI.pt'))

    imu_set.clear()
    RSI = imu_set.get_ipop()[0][0].view(3, 3).t()
    RMI = torch.tensor([[0, 1, 0], [0, 0, 1], [1, 0, 0]], dtype=torch.float).mm(RSI)
    # print(RMI.shape)
    torch.save(RMI, os.path.join(paths.temp_dir, 'RMI.pt'))

    #input('Stand straight in T-pose and press enter. The calibration will begin in 3 seconds')
    time.sleep(3)
    imu_set.clear()
    RIS = imu_set.get_ipop()[0]
    RSB = RMI.matmul(RIS).transpose(1, 2).matmul(torch.eye(3))
    return RMI, RSB

def tpose_calibration_noitom():

    c = input('Used cached RMI? [y]/n    (If you choose no, put imu 1 straight (x = Forward, y = Left, z = Up).')
    if c == 'n' or c == 'N':
        imu_set.clear()
        RSI = imu_set.get_noitom()[0][0].view(3, 3).t()
        RMI = torch.tensor([[1, 0, 0], [0, 0, 1], [0, -1, 0.]]).mm(RSI)
        torch.save(RMI, os.path.join(paths.temp_dir, 'RMI.pt'))
    else:
        print("여기!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
        RMI = torch.load(os.path.join(paths.temp_dir, 'RMI.pt'))

    input('Stand straight in T-pose and press enter. The calibration will begin in 3 seconds')
    time.sleep(3)
    imu_set.clear()
    RIS = imu_set.get_noitom()[0]
    RSB = RMI.matmul(RIS).transpose(1, 2).matmul(torch.eye(3))
    return RMI, RSB

if __name__ == '__main__':
    UDPStationBroadcastReceiver().start()
    UDPServer().start()


    os.makedirs(paths.temp_dir, exist_ok=True)
    os.makedirs(paths.live_record_dir, exist_ok=True)

    is_executable = False
    #server_for_unity = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    #server_for_unity.bind(('', 8888))
    #server_for_unity.listen(1)
    #print('Server start. Waiting for unity3d to connect.')
    ##if paths.unity_file != '' and os.path.exists(paths.unity_file):
    #    win32api.ShellExecute(0, 'open', os.path.abspath(paths.unity_file), '', '', 1)
    #    is_executable = True
    #conn, addr = server_for_unity.accept()


    test = False

    time.sleep(1)
    imu_set = IMUSet(test)
    RMI, RSB = tpose_calibration_ipop()
    #RMI, RSB = tpose_calibration_noitom()
    net = PIP()
    clock = Clock()
    imu_set.clear()
    data = {'RMI': RMI, 'RSB': RSB, 'aM': [], 'RMB': []}

    # print(DataManager().process_dipimu()[0])

    g_x = []
    g_y = []
    # 테스트 코드!!!!!!!!!!!!
    if test:
        test_a_list, test_q_list, pose_gt = DataManager().process_dipimu()
        for i in range(len(test_q_list)):
        # for i in range(20):
            clock.tick(100)
            q = test_q_list[i]
            a = test_a_list[i]
            # a = -torch.tensor(a) / 1000 * 9.8                        # acceleration is reversed
            # a = q.bmm(a.unsqueeze(-1)).squeeze(-1) + torch.tensor([0., 0., 9.8])   # calculate global free acceleration

            p = pose_gt[i]

            g_x.append(i)
            g_y.append(np.linalg.norm(np.array(a[1])))

            # # nan 데이터 0.0으로 변경
            # q = torch.nan_to_num(q, nan=0.0)
            # a = np.nan_to_num(a, nan=0.0).tolist()

            # print(q)
            # print(a)
            # print(imu_set.test_i)
            # print('------------------------------------------------------------------')
            RMB = RMI.matmul(q).matmul(RSB)
            a = torch.tensor(a)
            aM = a.mm(RMI.t())

            #RIS, aI = imu_set.get_noitom()
            #RMB = RMI.matmul(RIS).matmul(RSB)
            #aM = aI.mm(RMI.t())
            start_time = time.perf_counter()        
            pose, tran, cj, grf = net.forward_frame(aM.view(1, 6, 3).float(), RMB.view(1, 6, 3, 3).float(), return_grf=True)
            #pose, tran = net.forward()
            end_time = time.perf_counter()
            execution_time = (end_time-start_time) * 1000
            pose = art.math.rotation_matrix_to_axis_angle(pose).view(-1, 72)
            tran = tran.view(-1, 3)


            tran = torch.zeros(1,3)
            tran = torch.zeros(1,3)

                
            # send motion to Unity
            s = ','.join(['%g' % v for v in pose.view(-1)]) + '#' + \
                ','.join(['%g' % v for v in tran.view(-1)]) + '#' + \
                ','.join(['%d' % v for v in cj]) + '#' + \
                (','.join(['%g' % v for v in grf.view(-1)]) if grf is not None else '') + '$'
            #print(s)
            #print("-----------------------------")
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            server_address = ('192.168.201.199', 5005)
            sock.sendto(s.encode('utf-8'), server_address)

            # 2차원 그래프 그리기
        plt.plot(g_x, g_y, marker='o', linestyle='-', color='b', label="Data 1")

        # 그래프에 제목, 축 이름 설정
        plt.title("2D Graph of Two Arrays")
        plt.xlabel("X-axis")
        plt.ylabel("Y-axis")

        # 범례 추가
        plt.legend()

        # 그래프 보여주기
        plt.show()

    # 실시간 센서 코드!!!!!!!!!!!!

    i_test = 0
    while not test:
        # if i_test == 1000:


        #     plt.plot(g_x, g_y, marker='o', linestyle='-', color='b', label="Data 1")

        #         # 그래프에 제목, 축 이름 설정
        #     plt.title("2D Graph of Two Arrays")
        #     plt.xlabel("X-axis")
        #     plt.ylabel("Y-axis")

        #     # 범례 추가
        #     plt.legend()

        #     # 그래프 보여주기
        #     plt.show()
        #     break;

        # clock.tick(60)
        q, a = imu_set.get_ipop()
        RMB = RMI.matmul(q).matmul(RSB)
        a = torch.tensor(a)
        
        # a = -torch.tensor(a) * 9.8                         # acceleration is reversed
        # a = -torch.tensor(a) * 9.8                         # acceleration is reversed
        # a = q.bmm(a.unsqueeze(-1)).squeeze(-1) + torch.tensor([0., 0., 9.8])   # calculate global free acceleration
        aM = a.mm(RMI.t())

        
        #가속도 그래프 확인용 (추후 삭제)
        g_x.append(i_test)
        g_y.append(np.linalg.norm(np.array(a[1])))
        i_test += 1

        

        #RIS, aI = imu_set.get_noitom()
        #RMB = RMI.matmul(RIS).matmul(RSB)
        #aM = aI.mm(RMI.t())
        start_time = time.perf_counter()        
        pose, tran, cj, grf = net.forward_frame(aM.view(1, 6, 3).float(), RMB.view(1, 6, 3, 3).float(), return_grf=True)
        end_time = time.perf_counter()
        execution_time = (end_time-start_time) * 1000
        pose = art.math.rotation_matrix_to_axis_angle(pose).view(-1, 72)
        tran = tran.view(-1, 3)
        
        
        # tran = torch.zeros(1,3) # 테스트용 (추후 삭제)   
                 
        # send motion to Unity
        s = ','.join(['%g' % v for v in pose.view(-1)]) + '#' + \
            ','.join(['%g' % v for v in tran.view(-1)]) + '#' + \
            ','.join(['%d' % v for v in cj]) + '#' + \
            (','.join(['%g' % v for v in grf.view(-1)]) if grf is not None else '') + '$'
        #print(s)
        #print("-----------------------------")
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        server_address = ('192.168.201.199', 5005)
        sock.sendto(s.encode('utf-8'), server_address)
        #try:
        #    conn.send(s.encode('utf8'))

        #except:
        #    break

        #data['aM'].append(aM)
        #data['RMB'].append(RMB)

        #if is_executable and keyboard.is_pressed('q'):
        #    break

        #print('\rfps: ', clock.get_fps(), end='')

    if is_executable:
        os.system('taskkill /F /IM "%s"' % os.path.basename(paths.unity_file))

    data['aM'] = torch.stack(data['aM'])
    data['RMB'] = torch.stack(data['RMB'])
    #torch.save(data, os.path.join(paths.live_record_dir, 'xsens' + datetime.datetime.now().strftime('%Y%m%d%H%M%S') + '.pt'))
    print('\rFinish.')
    
    
    
    
    
